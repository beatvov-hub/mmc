# 2026年10月 月報用 画像素材

ファイル名の数字は原稿の画像番号です。キャプチャは作業時点の公開画面です。サイトの更新により記事本文と表示が異なる場合があります。AI生成イラストは実際の画面・記録ではありません。既存イラストはMMCサイト等で使用している素材です。

|番号|素材とキャプション案|種類・補足|
|---|---|---|
|①|01-member-reference-sheet.jpg「MMCのAI社員11名と社外協力者ペチ」|既存の人物参照一覧。集合写真ではなくプロフィールの参照シートです。|
|②|02-lounge-hero-screen.png / 02-lounge-log-screen.png「社員ラウンジ Bean & Bits と、ある日の会話」|公開画面|
|③|03-game-center-screen.png「人間もAIも遊びに来る AI GAME CENTER」|公開画面|
|④|04-game-four-cards-screen.png「AI GAME CENTERで紹介する4作品」|紹介カードの公開画面。04-game-* は各ゲームのトップ画面です。プレイ中の画面ではありません。|
|⑤|05-agentgames-crazzzy-screen.png / 05-agentgames-cat-screen.png「Agent Gamesで公開した2作品」|外部サイトの掲載画面。CATは読み込み中の表示が含まれます。|
|⑥|06-rsu-screen.png / 06-reiwa-ninja-screen.png「制作を続けるゲームたち」|RSUはゲームのトップ画面、令和忍者は作品紹介画面。MY GENT COSTの画面は未収録。|
|⑦|未収録|note管理画面の実際の記録を使用。アカウント情報や個人情報を隠してください。|
|⑧・⑨|未収録|YouWareの実際の記事や検証資料のキャプチャを使用。|
|⑩|10-october-salary-screen.png「10月の給与一覧。MMCは創作世界の架空通貨です」|公開画面。ヘッダーが重ならないよう表示位置を調整。|
|⑪|未収録|正確な旧ロゴの原本を確認できていません。旧・新ロゴの実物を用いて作成してください。|
|⑫|12-information-sources-illustration.png「プロフィール、Webサイト、資料、タスクなどに分かれる情報のイメージ」|今回の新規AI生成。実際のシステム構成図ではない概念イラスト。|
|⑬|13-market-illustration.webp「Bean & Bits MARKETのイメージ」|既存の公式イラスト。|
|⑭|14-market-seasonal-screen.png「10月の期間限定メニュー」|公開画面。|
|⑮|15-pechi-product-screen.png / 15-pechi-sweet-potato.webp「ラウンジの会話から生まれたペチの焼きいも」|公開商品カード／既存の商品イラスト。|
|⑯|16-office-tour-screen.png / 16-office-entrance-illustration.webp「MMC OFFICE TOURとエントランスのイメージ」|公開紹介画面／既存イラスト。3Dの操作中画面ではありません。|
|⑰|17-office-floorplan-screen.png「バーチャルオフィスのフロアマップ」|公開画面。|
|⑱|18-puzzle-illustration.png「試行錯誤を続けたパズル企画のイメージ」|今回の新規AI生成。公開当時のパズル画面ではありません。|
|⑲|19-learning-room-hero-screen.png「AIを知る・使う・試す、AI学習室」|公開画面。|
|⑳|20-quiz-four-screen.png / 20-note-articles-screen.png「4資格のクイズと、体験から学ぶnote記事」|公開画面。|
|㉑|21-journal-screen.png「月報や読みものをまとめたMMCジャーナル」|公開画面。|
|㉒|22-halloween-event-screen.png / 22-halloween-visual.webp「MMC Halloween Party 2026」|イベント紹介画面／既存のイベント用イラスト。|
|㉓|23-halloween-group.webp「ゲームをモチーフに仮装した社員たち」|既存のイベント用集合イラスト。|
|㉔|未収録|イベント公開後、実際の公開内容から印象的な場面を選択。|

## 新規生成画像の指示内容

- ⑫：温かい紙細工風の小さなオフィスを中心に、プロフィール、サイト、資料、予定などの情報源がつながる様子を、文字やロゴを入れずに表現。
- ⑱：揃わないパズルのピース、鉛筆、消しゴムを使い、試作と調整の難しさを温かい紙細工風に表現。実際の画面や文字は作らない。
